<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(config('app.name')); ?></title>
    <?php echo $__env->make('includes.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>

    <div class="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
        data-sidebar-position="fixed" data-header-position="fixed">

        <aside class="left-sidebar">
            <!-- Sidebar scroll-->


            <?php if(auth()->guard('admin')->check()): ?>
                <?php echo $__env->make('includes.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <!-- Sidebar navigation-->
            <!-- Sidebar Start -->
            <!--  Sidebar End -->
            <!-- End Sidebar navigation -->
            <?php if(auth()->guard('user')->check()): ?>
                <?php echo $__env->make('includes.user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <!-- End Sidebar scroll-->
        </aside>



        <!--  Main wrapper -->
        <div class="body-wrapper">
            <!--  Header Start -->
            <?php if(auth()->guard('admin')->check()): ?>
                <?php echo $__env->make('includes.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php if(auth()->guard('user')->check()): ?>
                <?php echo $__env->make('includes.user.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>


            <!--  Header End -->


            
            <div class="container-fluid">

                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>

    </div>


    <?php echo $__env->make('includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('modals'); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <?php if(Session::has('login-success')): ?>
        <script>
            Swal.fire({
                title: "<?php echo e(Session::get('login-success')); ?>",
                text: "Selamat Datang",
                icon: "success"
            });
        </script>
    <?php endif; ?>
    <?php if(Session::has('success')): ?>
        <script>
            Swal.fire({
                title: "Berhasil",
                text: "<?php echo e(Session::get('success')); ?>",
                icon: "success"
            });
        </script>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <script>
            Swal.fire({
                title: "Gagal",
                text: "<?php echo e(Session::get('error')); ?>",
                icon: "error"
            });
        </script>
    <?php endif; ?>
</body>

</html>
<?php /**PATH D:\Data\laragon\Web\fspmi\resources\views/layout.blade.php ENDPATH**/ ?>