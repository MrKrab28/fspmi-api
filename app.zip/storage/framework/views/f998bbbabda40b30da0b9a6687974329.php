<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables/css/responsive.bootstrap4.css')); ?>">
<?php /**PATH D:\Data\laragon\Web\fspmi\resources\views/includes/datatables/styles.blade.php ENDPATH**/ ?>