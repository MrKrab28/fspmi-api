<link rel="stylesheet" href="<?php echo e(asset('assets/css/pengaduan.css')); ?>">
<link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/images/logos/favicon.png')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/css/styles.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/libs/sweetalert2/sweetalert2.min.css')); ?>">
<?php /**PATH D:\Data\laragon\Web\fspmi\resources\views/includes/styles.blade.php ENDPATH**/ ?>