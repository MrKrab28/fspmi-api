<script src="<?php echo e(asset('assets/plugins/datatables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables/js/responsive.bootstrap4.min.js')); ?>"></script>
<?php /**PATH D:\Data\laragon\Web\fspmi\resources\views/includes/datatables/scripts.blade.php ENDPATH**/ ?>