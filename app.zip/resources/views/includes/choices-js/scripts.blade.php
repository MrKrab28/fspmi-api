<script src="https://cdn.jsdelivr.net/npm/choices.js@9.0.1/public/assets/scripts/choices.min.js"></script>
<script>
    const element = document.querySelector('.js-choice');
    const choices = new Choices(element);
</script>
