<link rel="stylesheet" href="{{ asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/plugins/datatables/css/responsive.bootstrap4.css') }}">
